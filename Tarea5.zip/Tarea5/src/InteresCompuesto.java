import java.util.Scanner;

public class InteresCompuesto {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double capital;
        double tasaDeInteres;
        double periodos;
        double importe;
        System.out.print("Ingresa el valor de capital: ");
        capital = in.nextDouble();
        in.nextLine();
        System.out.print("Ingresa el numero de periodos: ");
        periodos = in.nextDouble();
        in.nextLine();
        System.out.print("Ingresa la tasa de interes: ");
        tasaDeInteres = in.nextDouble();
        in.nextLine();
        importe=capital*Math.pow(1+tasaDeInteres,periodos);
        System.out.println("Valor de importe: " + importe);
    }

}


