public class Promedio {
    public static void main(String[] args){
        int Pta= 13;
        int Emc= 12;
        int Efc= 10;
        int promedioFinal;

        promedioFinal= (Pta + Emc + Efc) / 3;

        if(promedioFinal>=11){
            System.out.println("El alumno aprobo con " + promedioFinal);
        }
        else {
            System.out.println("El alumno reprobo con " + promedioFinal);
        }

    }
}
